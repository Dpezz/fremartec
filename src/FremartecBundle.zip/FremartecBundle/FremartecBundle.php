<?php

namespace FremartecBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class FremartecBundle extends Bundle
{
}
